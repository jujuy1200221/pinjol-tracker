const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');
const requestIp = require('request-ip');
const axios = require('axios');

const PORT = process.env.PORT || 3000;

app.use(requestIp.mw());
app.use(express.static('public'));

app.get('/', async (req, res) => {
    const ip = req.clientIp;
    const time = new Date().toLocaleString();
    let location = "Unknown";

    try {
        const response = await axios.get(`https://ipapi.co/${ip}/json/`);
        if (response.data && response.data.city) {
            location = `${response.data.city}, ${response.data.region}, ${response.data.country_name}`;
        }
    } catch (error) {
        console.log("Location lookup failed:", error.message);
    }

    const log = `IP: ${ip}, Time: ${time}, Location: ${location}\n`;
    fs.appendFileSync('log.txt', log);

    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/online', (req, res) => {
    fs.readFile('log.txt', 'utf8', (err, data) => {
        if (err) return res.send('Belum ada data login.');
        res.type('text').send(data);
    });
});

app.listen(PORT, () => console.log(`Server jalan di http://localhost:${PORT}`));